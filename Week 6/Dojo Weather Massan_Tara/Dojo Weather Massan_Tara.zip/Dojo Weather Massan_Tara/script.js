console.log("test!")


var cookieFooter = document.querySelector(".footer")

function weatherReport() {
    alert("This page says" + "\n" + "Loading weather report...")
}

function accept() {
    cookieFooter.remove();
}

//function convert(element) {
  //  for(var i = 1; i<9; i++) {
    //    var temp +document.querySelector("#temp" + i);
      //  console.log(temp);
    //}
//}