console.log("Hello! ")

var likeCounter1 = 9;
var post1 = document.querySelector("#post1");

function like1() {
    likeCounter1 ++;
    post1.innerText = likeCounter1 + " like(s)"
}

var likeCounter2 = 12;
var post2 = document.querySelector("#post2");

function like2() {
    likeCounter2 ++;
    post2.innerText = likeCounter2 + " like(s)"
}

var likeCounter3 = 9;
var post3 = document.querySelector("#post3");

function like3() {
    likeCounter3 ++;
    post3.innerText = likeCounter3 + " like(s)"
}
